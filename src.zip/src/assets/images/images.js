const images = {
  logo1: require('./LogoNavBar1.jpeg'),
  logo2: require('./logBeneficios2.jpeg'),
  // logo3: require('./Logo3.jpeg'),
};

export default images;
